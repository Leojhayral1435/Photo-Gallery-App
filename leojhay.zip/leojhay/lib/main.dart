import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:typed_data';

void main() {
  runApp(PhotoGalleryApp());
}

class PhotoGalleryApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Photo Gallery',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: GalleryScreen(),
    );
  }
}

class GalleryScreen extends StatefulWidget {
  @override
  _GalleryScreenState createState() => _GalleryScreenState();
}

class _GalleryScreenState extends State<GalleryScreen> {
  List<Uint8List> _photos = [];
  List<Uint8List> _filteredPhotos = [];
  List<Uint8List> _recentlyDeleted = [];
  Set<Uint8List> _favoritePhotos = {};
  Map<String, List<Uint8List>> _albums = {};
  ImageFilter? _selectedFilter;

  @override
  void initState() {
    super.initState();
    _filteredPhotos = List.from(_photos);
  }

  Future<void> _pickImage() async {
    final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      final bytes = await pickedFile.readAsBytes();
      setState(() {
        _photos.add(bytes);
        _filteredPhotos.add(bytes);
      });
    }
  }

  void _toggleFavorite(Uint8List photo) {
    setState(() {
      if (_favoritePhotos.contains(photo)) {
        _favoritePhotos.remove(photo);
      } else {
        _favoritePhotos.add(photo);
      }
    });
  }

  void _deletePhoto(int index) {
    setState(() {
      Uint8List photo = _photos[index];
      _recentlyDeleted.add(photo);
      _photos.removeAt(index);
      _filteredPhotos.removeAt(index);
      _favoritePhotos.remove(photo);
    });
  }

  void _restorePhoto(Uint8List photo) {
    setState(() {
      _photos.add(photo);
      _filteredPhotos.add(photo);
      _recentlyDeleted.remove(photo);
    });
  }

  void _navigateToAlbums() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AlbumsScreen(albums: _albums, photos: _photos),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Photo Gallery')),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text(
                'Photo Gallery',
                style: TextStyle(color: Colors.white, fontSize: 24),
              ),
            ),
            ListTile(
              leading: Icon(Icons.favorite),
              title: Text('Favorites'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => FavoritesScreen(favoritePhotos: _favoritePhotos),
                  ),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.delete),
              title: Text('Recently Deleted'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => RecentlyDeletedScreen(
                      recentlyDeleted: _recentlyDeleted,
                      restorePhoto: _restorePhoto,
                    ),
                  ),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.photo_album),
              title: Text('Albums'),
              onTap: _navigateToAlbums,
            ),
          ],
        ),
      ),
      body: GridView.builder(
        padding: EdgeInsets.all(8.0),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 4.0,
          mainAxisSpacing: 4.0,
        ),
        itemCount: _filteredPhotos.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onDoubleTap: () => _toggleFavorite(_photos[index]),
            child: Stack(
              children: [
                Image.memory(_filteredPhotos[index], fit: BoxFit.cover, width: double.infinity),
                Positioned(
                  top: 0,
                  left: 0,
                  child: Icon(
                    _favoritePhotos.contains(_photos[index]) ? Icons.favorite : Icons.favorite_border,
                    color: _favoritePhotos.contains(_photos[index]) ? Colors.red : Colors.white,
                  ),
                ),
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: IconButton(
                    icon: Icon(Icons.delete, color: Colors.white),
                    onPressed: () => _deletePhoto(index),
                  ),
                ),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _pickImage,
        child: Icon(Icons.add_a_photo),
      ),
    );
  }
}

// Favorites Screen
class FavoritesScreen extends StatelessWidget {
  final Set<Uint8List> favoritePhotos;

  FavoritesScreen({required this.favoritePhotos});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Favorites')),
      body: GridView.builder(
        padding: EdgeInsets.all(8.0),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 4.0,
          mainAxisSpacing: 4.0,
        ),
        itemCount: favoritePhotos.length,
        itemBuilder: (context, index) {
          return Image.memory(favoritePhotos.elementAt(index), fit: BoxFit.cover);
        },
      ),
    );
  }
}

// Recently Deleted Screen
class RecentlyDeletedScreen extends StatelessWidget {
  final List<Uint8List> recentlyDeleted;
  final Function(Uint8List) restorePhoto;

  RecentlyDeletedScreen({required this.recentlyDeleted, required this.restorePhoto});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Recently Deleted')),
      body: GridView.builder(
        padding: EdgeInsets.all(8.0),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 4.0,
          mainAxisSpacing: 4.0,
        ),
        itemCount: recentlyDeleted.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () => restorePhoto(recentlyDeleted[index]),
            child: Stack(
              children: [
                Image.memory(recentlyDeleted[index], fit: BoxFit.cover),
                Positioned(
                  bottom: 5,
                  left: 5,
                  child: Icon(Icons.restore, color: Colors.white),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class AlbumsScreen extends StatefulWidget {
  final Map<String, List<Uint8List>> albums;
  final List<Uint8List> photos;

  AlbumsScreen({required this.albums, required this.photos});

  @override
  _AlbumsScreenState createState() => _AlbumsScreenState();
}

class _AlbumsScreenState extends State<AlbumsScreen> {
  final TextEditingController _albumController = TextEditingController();

  void _createAlbum() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Create Album'),
          content: TextField(
            controller: _albumController,
            decoration: InputDecoration(hintText: 'Enter album name'),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                String albumName = _albumController.text.trim();
                if (albumName.isNotEmpty && !widget.albums.containsKey(albumName)) {
                  setState(() {
                    widget.albums[albumName] = [];
                  });
                }
                _albumController.clear();
                Navigator.pop(context);
              },
              child: Text('Create'),
            ),
          ],
        );
      },
    );
  }

  void _addPhotoToAlbum(String albumName) {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return ListView.builder(
          itemCount: widget.photos.length,
          itemBuilder: (context, index) {
            return ListTile(
              leading: Image.memory(widget.photos[index], width: 50, height: 50, fit: BoxFit.cover),
              title: Text('Photo ${index + 1}'),
              onTap: () {
                setState(() {
                  widget.albums[albumName]?.add(widget.photos[index]);
                });
                Navigator.pop(context);
              },
            );
          },
        );
      },
    );
  }

  void _viewAlbum(String albumName) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AlbumPhotosScreen(albumName: albumName, photos: widget.albums[albumName]!),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Albums')),
      body: widget.albums.isEmpty
          ? Center(child: Text('No albums created yet.'))
          : ListView(
              children: widget.albums.keys.map((albumName) {
                return ListTile(
                  title: Text(albumName),
                  trailing: IconButton(
                    icon: Icon(Icons.add_photo_alternate),
                    onPressed: () => _addPhotoToAlbum(albumName),
                  ),
                  onTap: () => _viewAlbum(albumName),
                );
              }).toList(),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _createAlbum,
        child: Icon(Icons.create_new_folder),
      ),
    );
  }
}

// Album Photos Screen
class AlbumPhotosScreen extends StatelessWidget {
  final String albumName;
  final List<Uint8List> photos;

  AlbumPhotosScreen({required this.albumName, required this.photos});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(albumName)),
      body: photos.isEmpty
          ? Center(child: Text('No photos in this album.'))
          : GridView.builder(
              padding: EdgeInsets.all(8.0),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 4.0,
                mainAxisSpacing: 4.0,
              ),
              itemCount: photos.length,
              itemBuilder: (context, index) {
                return Image.memory(photos[index], fit: BoxFit.cover);
              },
            ),
    );
  }
}