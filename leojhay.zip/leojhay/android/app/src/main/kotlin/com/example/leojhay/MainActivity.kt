package com.example.leojhay

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
